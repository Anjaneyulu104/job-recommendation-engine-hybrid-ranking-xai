# Streamlit Resume Recommender

This package is ready to run locally.

## Files
- app.py
- requirements.txt
- large_resume_dataset.csv

## Run

Open PowerShell in this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The app trains its model directly from `large_resume_dataset.csv`, so no separate artifacts folder is required.
