
# ============================================================
# AI RESUME JOB RECOMMENDATION ENGINE
# Hybrid NLP Ranking + Explainability + Feedback Learning
#
# Academic research prototype
# No live hiring decisions
# No participant data storage
# ============================================================

from pathlib import Path
from collections import Counter
import re
import warnings

import numpy as np
import pandas as pd
import streamlit as st

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

RANDOM_SEED = 42
TEST_SIZE = 0.20

st.set_page_config(
    page_title="AI Resume Job Recommendation Engine",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = Path(__file__).resolve().parent

st.markdown(
    """
<style>
.block-container {padding-top: 1.5rem; padding-bottom: 3rem; max-width: 1450px;}
[data-testid="stSidebar"] {border-right: 1px solid #e5e7eb;}
.hero-card {
    padding: 2.2rem; border-radius: 22px;
    background: linear-gradient(135deg,#0f172a 0%,#1e293b 55%,#334155 100%);
    color: white; margin-bottom: 1.5rem;
    box-shadow: 0 12px 35px rgba(0,0,0,0.13);
}
.hero-title {font-size: 2.35rem; font-weight: 800; margin-bottom: 0.4rem;}
.hero-subtitle {color: #cbd5e1; font-size: 1.05rem;}
.ethics-card {
    padding: 1rem 1.2rem; border-left: 5px solid #334155;
    background: #f8fafc; border-radius: 10px; margin-bottom: 1rem;
}
.recommend-card {
    padding: 1.25rem; border: 1px solid #e2e8f0; border-radius: 18px;
    margin-bottom: 0.8rem; box-shadow: 0 4px 18px rgba(15,23,42,0.05);
}
.rank-badge {
    background: #0f172a; color: white; padding: 0.3rem 0.6rem;
    border-radius: 8px; font-size: 0.85rem; font-weight: 700; margin-right: 0.45rem;
}
.match-pill {
    display: inline-block; background: #dcfce7; color: #166534;
    padding: 0.25rem 0.6rem; border-radius: 999px; margin: 0.12rem; font-size: 0.82rem;
}
.gap-pill {
    display: inline-block; background: #fee2e2; color: #991b1b;
    padding: 0.25rem 0.6rem; border-radius: 999px; margin: 0.12rem; font-size: 0.82rem;
}
.score-good {font-weight: 700; font-size: 1.15rem;}
</style>
""",
    unsafe_allow_html=True,
)

REQUIRED_COLUMNS = {"Experience_Years", "Skills", "Education", "Applied_Job_Role"}

def find_resume_dataset():
    preferred_names = [
        "large_resume_dataset.csv",
        "ai_resume_matcher.csv",
        "resume_dataset.csv",
    ]
    for file_name in preferred_names:
        for csv_path in BASE_DIR.rglob(file_name):
            try:
                sample = pd.read_csv(csv_path, nrows=5)
                if REQUIRED_COLUMNS.issubset(sample.columns):
                    return csv_path
            except Exception:
                continue
    for csv_path in BASE_DIR.rglob("*.csv"):
        try:
            sample = pd.read_csv(csv_path, nrows=5)
            if REQUIRED_COLUMNS.issubset(sample.columns):
                return csv_path
        except Exception:
            continue
    return None

DATASET_PATH = find_resume_dataset()

if DATASET_PATH is None:
    st.error("Could not find the AI Resume Matcher dataset.")
    st.markdown("""
Place **large_resume_dataset.csv** in the same folder as `app.py`.

The CSV must contain:
`Name`, `Experience_Years`, `Skills`, `Education`, `Applied_Job_Role`
""")
    st.stop()

def clean_string(value):
    if pd.isna(value):
        return ""
    value = str(value).replace("\n", " ").replace("\r", " ")
    return re.sub(r"\s+", " ", value).strip()

def normalise_skill(skill):
    skill = str(skill).lower().strip()
    skill = re.sub(r"[^a-z0-9+#.\- ]", "", skill)
    return re.sub(r"\s+", " ", skill).strip()

def parse_skills(value):
    if pd.isna(value):
        return []
    return [part.strip() for part in re.split(r"[,;|/]+", str(value)) if part.strip()]

@st.cache_data
def load_and_prepare_dataset(dataset_path_string):
    dataframe = pd.read_csv(dataset_path_string)
    missing_columns = REQUIRED_COLUMNS - set(dataframe.columns)
    if missing_columns:
        raise ValueError("Dataset is missing columns: " + ", ".join(sorted(missing_columns)))

    dataframe = dataframe[
        ["Experience_Years", "Skills", "Education", "Applied_Job_Role"]
    ].copy()

    dataframe["Skills"] = dataframe["Skills"].fillna("").astype(str).map(clean_string)
    dataframe["Education"] = dataframe["Education"].fillna("Unknown").astype(str).map(clean_string)
    dataframe["Applied_Job_Role"] = dataframe["Applied_Job_Role"].fillna("Unknown").astype(str).map(clean_string)
    dataframe["Experience_Years"] = (
        pd.to_numeric(dataframe["Experience_Years"], errors="coerce")
        .fillna(0)
        .clip(lower=0, upper=50)
    )

    dataframe = dataframe[dataframe["Applied_Job_Role"].str.len().gt(0)]
    dataframe = dataframe[dataframe["Skills"].str.len().gt(0)]
    dataframe = dataframe.drop_duplicates().reset_index(drop=True)
    return dataframe

resume_df = load_and_prepare_dataset(str(DATASET_PATH))

def create_skill_vocabulary(dataframe):
    skills = set()
    for value in dataframe["Skills"]:
        for skill in parse_skills(value):
            if skill.strip():
                skills.add(skill.strip())
    return sorted(skills, key=str.lower)

SKILL_VOCABULARY = create_skill_vocabulary(resume_df)

def create_ml_text(row):
    experience = float(row["Experience_Years"])
    if experience < 2:
        band = "entry level experience"
    elif experience < 5:
        band = "early career experience"
    elif experience < 8:
        band = "mid level experience"
    else:
        band = "senior experience"

    return f"skills {row['Skills']} education {row['Education']} {band}"

resume_df["Model_Text"] = resume_df.apply(create_ml_text, axis=1)

@st.cache_resource
def train_supervised_model(dataframe):
    X = dataframe["Model_Text"]
    y = dataframe["Applied_Job_Role"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y
    )

    pipeline = Pipeline(
        steps=[
            (
                "tfidf",
                TfidfVectorizer(
                    lowercase=True,
                    ngram_range=(1, 2),
                    min_df=2,
                    max_df=0.98,
                    sublinear_tf=True,
                    max_features=12000,
                ),
            ),
            (
                "classifier",
                LogisticRegression(
                    max_iter=2500,
                    random_state=RANDOM_SEED,
                    class_weight="balanced",
                    C=2.0,
                ),
            ),
        ]
    )

    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    precision, recall, macro_f1, _ = precision_recall_fscore_support(
        y_test, predictions, average="macro", zero_division=0
    )

    report = classification_report(
        y_test, predictions, output_dict=True, zero_division=0
    )

    metrics = {
        "accuracy": accuracy,
        "macro_precision": precision,
        "macro_recall": recall,
        "macro_f1": macro_f1,
    }
    return pipeline, metrics, report

trained_model, model_metrics, classification_report_dict = train_supervised_model(resume_df)

def build_role_profiles(dataframe, top_skill_count=8):
    role_profiles = []

    for role_name, group in dataframe.groupby("Applied_Job_Role"):
        skill_counter = Counter()

        for skill_string in group["Skills"]:
            for skill in parse_skills(skill_string):
                normalized = normalise_skill(skill)
                if normalized:
                    skill_counter[normalized] += 1

        top_normalized_skills = [
            skill for skill, _ in skill_counter.most_common(top_skill_count)
        ]

        readable_skills = []
        for normalized_skill in top_normalized_skills:
            candidate = None
            for original_skill in SKILL_VOCABULARY:
                if normalise_skill(original_skill) == normalized_skill:
                    candidate = original_skill
                    break
            readable_skills.append(candidate if candidate else normalized_skill.title())

        median_experience = float(group["Experience_Years"].median())
        common_education = group["Education"].mode()
        common_education = common_education.iloc[0] if len(common_education) else "Unknown"

        profile_text = (
            f"{role_name}. Skills: {', '.join(readable_skills)}. "
            f"Education: {common_education}. Experience: {median_experience:g} years."
        )

        role_profiles.append(
            {
                "Job_Role": role_name,
                "Required_Skills": readable_skills,
                "Median_Experience": median_experience,
                "Typical_Education": common_education,
                "Profile_Text": profile_text,
                "Training_Records": len(group),
            }
        )

    return (
        pd.DataFrame(role_profiles)
        .sort_values("Job_Role")
        .reset_index(drop=True)
    )

ROLE_PROFILE_DF = build_role_profiles(resume_df)

@st.cache_resource
def build_semantic_model(role_profile_texts):
    vectorizer = TfidfVectorizer(
        lowercase=True, ngram_range=(1, 2), sublinear_tf=True
    )
    matrix = vectorizer.fit_transform(role_profile_texts)
    return vectorizer, matrix

semantic_vectorizer, role_profile_matrix = build_semantic_model(
    ROLE_PROFILE_DF["Profile_Text"].tolist()
)

def extract_txt_text(uploaded_file):
    raw = uploaded_file.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="ignore")

def extract_pdf_text(uploaded_file):
    from pypdf import PdfReader
    reader = PdfReader(uploaded_file)
    pages = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            pages.append(text)
    return "\n".join(pages)

def extract_docx_text(uploaded_file):
    from docx import Document
    document = Document(uploaded_file)
    return "\n".join(
        p.text for p in document.paragraphs if p.text.strip()
    )

def extract_uploaded_resume_text(uploaded_file):
    if uploaded_file is None:
        return ""
    file_name = uploaded_file.name.lower()
    if file_name.endswith(".txt"):
        return extract_txt_text(uploaded_file)
    if file_name.endswith(".pdf"):
        return extract_pdf_text(uploaded_file)
    if file_name.endswith(".docx"):
        return extract_docx_text(uploaded_file)
    return ""

SKILL_ALIASES = {
    "Python": ["python"],
    "SQL": ["sql", "mysql", "postgresql"],
    "Machine Learning": ["machine learning", "machine-learning"],
    "Deep Learning": ["deep learning"],
    "Excel": ["excel", "microsoft excel", "ms excel"],
    "Statistics": ["statistics", "statistical analysis"],
    "AWS": ["aws", "amazon web services"],
    "Azure": ["azure", "microsoft azure"],
    "Docker": ["docker"],
    "Kubernetes": ["kubernetes", "k8s"],
    "Linux": ["linux"],
    "DevOps": ["devops", "dev ops"],
    "Java": ["java"],
    "JavaScript": ["javascript"],
    "React": ["react", "reactjs"],
    "Power BI": ["power bi", "powerbi"],
    "Tableau": ["tableau"],
    "Git": ["git", "github"],
}

def skill_present(text, skill):
    return bool(
        re.search(
            rf"(?<!\w){re.escape(skill.lower())}(?!\w)",
            text,
        )
    )

def extract_resume_skills(resume_text):
    text = resume_text.lower()
    detected = set()

    for skill in SKILL_VOCABULARY:
        normalized = normalise_skill(skill)
        if normalized and skill_present(text, normalized):
            detected.add(skill)

    for canonical, aliases in SKILL_ALIASES.items():
        for alias in aliases:
            if skill_present(text, alias):
                matched = None
                for known_skill in SKILL_VOCABULARY:
                    if normalise_skill(known_skill) == normalise_skill(canonical):
                        matched = known_skill
                        break
                detected.add(matched if matched else canonical)
                break

    return sorted(detected, key=str.lower)

def extract_experience_years(resume_text):
    text = resume_text.lower()
    patterns = [
        r"(\d+(?:\.\d+)?)\s*\+?\s*years?\s+(?:of\s+)?experience",
        r"experience\s*(?:of|:)?\s*(\d+(?:\.\d+)?)\s*\+?\s*years?",
        r"(\d+(?:\.\d+)?)\s*\+?\s*yrs?\s+(?:of\s+)?experience",
    ]
    values = []

    for pattern in patterns:
        for match in re.findall(pattern, text):
            try:
                years = float(match)
                if 0 <= years <= 50:
                    values.append(years)
            except Exception:
                pass

    return float(max(values)) if values else 0.0

EDUCATION_PATTERNS = [
    ("PhD", [r"\bph\.?d\b", r"\bdoctorate\b"]),
    ("M.Tech", [r"\bm\.?\s*tech\b", r"master of technology"]),
    ("MCA", [r"\bmca\b", r"master of computer applications"]),
    ("MBA", [r"\bmba\b", r"master of business administration"]),
    ("M.Sc", [r"\bm\.?\s*sc\b", r"master of science"]),
    ("B.Tech in CS", [r"\bb\.?\s*tech\b", r"bachelor of technology", r"computer science", r"computer engineering"]),
    ("BCA", [r"\bbca\b", r"bachelor of computer applications"]),
    ("B.Sc", [r"\bb\.?\s*sc\b", r"bachelor of science"]),
]

def extract_education(resume_text):
    text = resume_text.lower()
    for label, patterns in EDUCATION_PATTERNS:
        for pattern in patterns:
            if re.search(pattern, text):
                return label
    return "Unknown"

def calculate_skill_fit(candidate_skills, required_skills):
    candidate_set = {normalise_skill(skill) for skill in candidate_skills}
    required_set = {normalise_skill(skill) for skill in required_skills}
    candidate_set.discard("")
    required_set.discard("")
    if not required_set:
        return 0.0
    return len(candidate_set & required_set) / len(required_set)

def calculate_experience_fit(candidate_years, required_years):
    try:
        candidate_years = float(candidate_years)
        required_years = float(required_years)
    except Exception:
        return 0.5
    if required_years <= 0:
        return 1.0
    return float(min(candidate_years / required_years, 1.0))

EDUCATION_RANK = {
    "Unknown": 0, "B.Sc": 1, "BCA": 1, "B.Tech in CS": 2,
    "M.Sc": 3, "MCA": 3, "MBA": 3, "M.Tech": 4, "PhD": 5,
}

def calculate_education_fit(candidate_education, typical_education):
    candidate_rank = EDUCATION_RANK.get(candidate_education, 0)
    typical_rank = EDUCATION_RANK.get(typical_education, 0)
    if typical_rank == 0:
        return 0.75
    if candidate_rank >= typical_rank:
        return 1.0
    return max(candidate_rank / typical_rank, 0.25)

def make_candidate_model_text(skills, education, experience):
    if experience < 2:
        band = "entry level experience"
    elif experience < 5:
        band = "early career experience"
    elif experience < 8:
        band = "mid level experience"
    else:
        band = "senior experience"

    return f"skills {', '.join(skills)} education {education} {band}"

def get_ml_probabilities(skills, education, experience):
    model_text = make_candidate_model_text(skills, education, experience)
    probabilities = trained_model.predict_proba([model_text])[0]
    classes = trained_model.named_steps["classifier"].classes_
    return {
        str(role): float(prob)
        for role, prob in zip(classes, probabilities)
    }

def calculate_semantic_similarity(resume_text):
    resume_vector = semantic_vectorizer.transform([resume_text])
    similarities = cosine_similarity(resume_vector, role_profile_matrix)[0]

    min_score = similarities.min()
    max_score = similarities.max()

    if max_score > min_score:
        similarities = (similarities - min_score) / (max_score - min_score)

    return similarities

if "role_feedback" not in st.session_state:
    st.session_state["role_feedback"] = {}

def get_feedback_score(role):
    value = st.session_state["role_feedback"].get(role, 0)
    if value > 0:
        return 1.0
    if value < 0:
        return -1.0
    return 0.0

HYBRID_WEIGHTS = {
    "skill": 0.40,
    "semantic": 0.25,
    "ml": 0.15,
    "experience": 0.10,
    "education": 0.05,
    "feedback": 0.05,
}

def generate_recommendations(resume_text, skills, education, experience, top_n):
    ml_scores = get_ml_probabilities(skills, education, experience)
    semantic_scores = calculate_semantic_similarity(resume_text)

    rows = []

    for index, profile in ROLE_PROFILE_DF.iterrows():
        role = profile["Job_Role"]
        required_skills = profile["Required_Skills"]

        skill_fit = calculate_skill_fit(skills, required_skills)
        semantic_fit = float(semantic_scores[index])
        ml_probability = ml_scores.get(role, 0.0)
        experience_fit = calculate_experience_fit(
            experience, profile["Median_Experience"]
        )
        education_fit = calculate_education_fit(
            education, profile["Typical_Education"]
        )
        feedback_signal = get_feedback_score(role)
        feedback_component = 0.5 + 0.5 * feedback_signal

        hybrid_score = (
            HYBRID_WEIGHTS["skill"] * skill_fit
            + HYBRID_WEIGHTS["semantic"] * semantic_fit
            + HYBRID_WEIGHTS["ml"] * ml_probability
            + HYBRID_WEIGHTS["experience"] * experience_fit
            + HYBRID_WEIGHTS["education"] * education_fit
            + HYBRID_WEIGHTS["feedback"] * feedback_component
        )

        candidate_map = {
            normalise_skill(skill): skill for skill in skills
        }
        required_map = {
            normalise_skill(skill): skill for skill in required_skills
        }

        matched_keys = set(candidate_map) & set(required_map)
        missing_keys = set(required_map) - set(candidate_map)

        rows.append(
            {
                "Job Role": role,
                "Hybrid Score": hybrid_score,
                "Skill Fit": skill_fit,
                "Semantic Similarity": semantic_fit,
                "ML Probability": ml_probability,
                "Experience Fit": experience_fit,
                "Education Fit": education_fit,
                "Feedback Signal": feedback_signal,
                "Matched Skills": sorted([required_map[k] for k in matched_keys]),
                "Missing Skills": sorted([required_map[k] for k in missing_keys]),
            }
        )

    results = pd.DataFrame(rows).sort_values(
        "Hybrid Score", ascending=False
    ).reset_index(drop=True)

    results["Rank"] = np.arange(1, len(results) + 1)
    return results.head(top_n)

def create_explanation(row):
    reasons = []

    if row["Matched Skills"]:
        reasons.append(
            "The resume matches "
            + ", ".join(row["Matched Skills"][:5])
            + "."
        )

    if row["Semantic Similarity"] >= 0.70:
        reasons.append(
            "The overall resume content shows strong semantic alignment with this role."
        )
    elif row["Semantic Similarity"] >= 0.40:
        reasons.append(
            "The resume shows moderate semantic alignment with this role."
        )

    if row["Experience Fit"] >= 0.90:
        reasons.append(
            "The candidate's experience is consistent with the typical role profile."
        )

    if row["Education Fit"] >= 0.90:
        reasons.append(
            "The education profile is compatible with this role."
        )

    if row["Missing Skills"]:
        reasons.append(
            "Potential development areas include "
            + ", ".join(row["Missing Skills"][:4])
            + "."
        )

    return " ".join(reasons)

st.markdown(
    """
<div class="hero-card">
<div class="hero-title">💼 AI Resume Job Recommendation Engine</div>
<div class="hero-subtitle">
Hybrid NLP ranking • Machine learning • Semantic matching •
Explainable AI • Feedback-driven recommendations
</div>
</div>
""",
    unsafe_allow_html=True,
)

st.markdown(
    """
<div class="ethics-card">
<b>Academic research prototype only.</b><br>
The system is designed for dissertation research and demonstration.
It must not be used to make live hiring decisions. Resume information
is processed for the current application session and is not intentionally
stored in a participant database.
</div>
""",
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("System configuration")

    top_n = st.slider(
        "Recommendations",
        min_value=3,
        max_value=8,
        value=5,
        step=1,
    )

    st.markdown("---")
    st.subheader("Dataset")
    st.write(f"**{DATASET_PATH.name}**")
    st.write(f"Records: **{len(resume_df):,}**")
    st.write(f"Job roles: **{resume_df['Applied_Job_Role'].nunique()}**")
    st.write(f"Skills: **{len(SKILL_VOCABULARY)}**")

    st.markdown("---")
    st.subheader("Supervised baseline")
    st.metric("Test accuracy", f"{model_metrics['accuracy']:.1%}")
    st.metric("Macro F1", f"{model_metrics['macro_f1']:.1%}")

    st.caption(
        "The Applied_Job_Role classifier is retained as a baseline signal. "
        "The final recommendation uses hybrid competency ranking."
    )

    st.markdown("---")
    st.subheader("Hybrid weights")
    st.write("Skills: **40%**")
    st.write("Semantic: **25%**")
    st.write("ML signal: **15%**")
    st.write("Experience: **10%**")
    st.write("Education: **5%**")
    st.write("Feedback: **5%**")

upload_column, paste_column = st.columns(2)

with upload_column:
    st.subheader("Upload resume")
    uploaded_resume = st.file_uploader(
        "PDF, DOCX or TXT",
        type=["pdf", "docx", "txt"],
    )

with paste_column:
    st.subheader("Or paste resume text")
    pasted_resume = st.text_area(
        "Resume text",
        height=180,
        placeholder=(
            "B.Tech in Computer Science with 5 years of experience "
            "in Python, SQL, Machine Learning, Excel and Statistics..."
        ),
        label_visibility="collapsed",
    )

resume_text = ""

if uploaded_resume is not None:
    resume_text = extract_uploaded_resume_text(uploaded_resume)

if pasted_resume.strip():
    if resume_text.strip():
        resume_text += "\n" + pasted_resume
    else:
        resume_text = pasted_resume

if resume_text.strip():
    detected_skills = extract_resume_skills(resume_text)
    experience_years = extract_experience_years(resume_text)
    education = extract_education(resume_text)

    st.markdown("---")
    st.subheader("Extracted candidate profile")

    metric_1, metric_2, metric_3 = st.columns(3)

    metric_1.metric("Skills found", len(detected_skills))
    metric_2.metric("Experience years", f"{experience_years:g}")
    metric_3.metric("Education", education)

    if detected_skills:
        st.markdown("**Detected skills:** " + ", ".join(detected_skills))
    else:
        st.warning("No skills from the known dataset vocabulary were detected.")

    recommendations = generate_recommendations(
        resume_text=resume_text,
        skills=detected_skills,
        education=education,
        experience=experience_years,
        top_n=top_n,
    )

    st.markdown("---")
    st.subheader("Recommended job roles")

    for _, row in recommendations.iterrows():
        rank = int(row["Rank"])
        role = row["Job Role"]
        score = float(row["Hybrid Score"])

        st.markdown(
            f"""
<div class="recommend-card">
<span class="rank-badge">#{rank}</span>
<span style="font-size:1.3rem;font-weight:750;">{role}</span>
<br><br>
<span class="score-good">Hybrid recommendation score: {score:.3f}</span>
</div>
""",
            unsafe_allow_html=True,
        )

        score_1, score_2, score_3, score_4 = st.columns(4)

        score_1.metric("Skill fit", f"{row['Skill Fit']:.1%}")
        score_2.metric("Semantic fit", f"{row['Semantic Similarity']:.1%}")
        score_3.metric("Experience fit", f"{row['Experience Fit']:.1%}")
        score_4.metric("ML signal", f"{row['ML Probability']:.1%}")

        st.markdown("**Why this role was recommended**")
        st.write(create_explanation(row))

        matched = row["Matched Skills"]
        if matched:
            st.markdown("**Matched skills**")
            matched_html = "".join(
                f'<span class="match-pill">{skill}</span>'
                for skill in matched
            )
            st.markdown(matched_html, unsafe_allow_html=True)

        missing = row["Missing Skills"]
        if missing:
            st.markdown("**Potential skill gaps**")
            gap_html = "".join(
                f'<span class="gap-pill">{skill}</span>'
                for skill in missing[:8]
            )
            st.markdown(gap_html, unsafe_allow_html=True)

        feedback_left, feedback_right = st.columns(2)

        with feedback_left:
            if st.button(
                f"👍 Useful — {role}",
                key=f"useful_{rank}_{role}",
            ):
                st.session_state["role_feedback"][role] = 1
                st.rerun()

        with feedback_right:
            if st.button(
                f"👎 Not useful — {role}",
                key=f"not_useful_{rank}_{role}",
            ):
                st.session_state["role_feedback"][role] = -1
                st.rerun()

        st.markdown("---")

    with st.expander("Technical recommendation score breakdown"):
        technical_columns = [
            "Rank",
            "Job Role",
            "Hybrid Score",
            "Skill Fit",
            "Semantic Similarity",
            "ML Probability",
            "Experience Fit",
            "Education Fit",
            "Feedback Signal",
        ]

        technical_df = recommendations[technical_columns].copy()

        st.dataframe(
            technical_df.style.format(
                {
                    "Hybrid Score": "{:.3f}",
                    "Skill Fit": "{:.3f}",
                    "Semantic Similarity": "{:.3f}",
                    "ML Probability": "{:.3f}",
                    "Experience Fit": "{:.3f}",
                    "Education Fit": "{:.3f}",
                    "Feedback Signal": "{:.0f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    export_df = recommendations.copy()

    export_df["Matched Skills"] = export_df["Matched Skills"].apply(
        lambda values: ", ".join(values)
    )

    export_df["Missing Skills"] = export_df["Missing Skills"].apply(
        lambda values: ", ".join(values)
    )

    export_df["Explanation"] = recommendations.apply(
        create_explanation,
        axis=1,
    )

    csv_data = export_df.to_csv(index=False).encode("utf-8")

    st.download_button(
        "⬇ Download recommendations",
        data=csv_data,
        file_name="job_recommendation_results.csv",
        mime="text/csv",
    )

else:
    st.info("Upload a resume or paste resume text to generate job recommendations.")

st.markdown("---")

with st.expander("About the research model"):
    st.markdown(
        f"""
### Model architecture

The application trains a supervised **TF-IDF + Logistic Regression** model using:

- Skills
- Education
- Experience level

The target used for the diagnostic classification component is:

**Applied_Job_Role**

The final recommendation is not based only on the classifier. A hybrid ranking score is calculated using:

| Component | Weight |
|---|---:|
| Skill compatibility | 40% |
| Semantic similarity | 25% |
| ML probability | 15% |
| Experience compatibility | 10% |
| Education compatibility | 5% |
| Session feedback | 5% |

### Current supervised baseline

- Accuracy: **{model_metrics['accuracy']:.3f}**
- Macro Precision: **{model_metrics['macro_precision']:.3f}**
- Macro Recall: **{model_metrics['macro_recall']:.3f}**
- Macro F1: **{model_metrics['macro_f1']:.3f}**

A low Applied_Job_Role classification score should not be hidden or artificially inflated.
The synthetic dataset may contain weak relationships between candidate attributes and the original
applied-role label. Therefore, the dissertation should treat the supervised classifier as a diagnostic
baseline and the hybrid competency recommender as the main prototype.
"""
    )

st.caption(
    "Job Recommendation Engine with Hybrid Ranking, Explainability and "
    "Feedback-Driven Learning using NLP — academic research prototype. "
    "Not intended for automated hiring decisions."
)
